# GloryFin — Site + MVP réel (Next.js + Supabase)

Site complet : page vitrine publique (`/`) avec simulateur interactif, plus
une vraie application derrière (`/login`, `/dashboard`, `/apply`, `/admin`) :
inscription/connexion réelles, base de données réelle, demandes de prêt
persistées, back-office admin protégé par rôle.

## Structure des pages

- `/` — page vitrine publique (hero, simulateur, produits, sécurité)
- `/login` — connexion / inscription
- `/dashboard` — espace client (protégé, nécessite un compte)
- `/apply` — nouvelle demande de prêt (protégé)
- `/admin` — back-office interne, réservé au rôle `admin` (protégé)

Ce que ce projet **n'est pas** : un établissement de crédit agréé. Le scoring
est une règle simple à but de démonstration (`lib/scoring.js`), il n'y a pas
de connexion à un bureau de crédit réel, et aucun fonds n'est réellement
transféré. À ne pas utiliser pour de vrais prêts sans agrément ACPR et sans
remplacer le scoring par un vrai moteur de décision.

## 1. Créer le projet Supabase (gratuit)

1. Va sur [supabase.com](https://supabase.com) → crée un compte → "New project"
2. Une fois créé, va dans **SQL Editor** → colle le contenu de
   `supabase/schema.sql` → **Run**. Ça crée les tables et la sécurité (RLS).
3. Va dans **Project Settings → API** : récupère `Project URL` et `anon public key`.

## 2. Configurer le projet en local

```bash
npm install
cp .env.local.example .env.local
# remplis .env.local avec les clés récupérées à l'étape 1
npm run dev
```

Le site tourne sur http://localhost:3000

## 3. Créer ton premier compte admin

1. Inscris-toi normalement sur le site (bouton "S'inscrire")
2. Dans Supabase → **SQL Editor**, exécute :
   ```sql
   update public.profiles set role = 'admin' where email = 'ton-email@example.com';
   ```
3. Reconnecte-toi : le bouton "Espace interne" apparaît, menant vers `/admin`

## 4. Déployer en ligne (Vercel, gratuit)

1. Crée un dépôt GitHub avec ce code (`git init`, `git add .`, `git commit`, push)
2. Va sur [vercel.com](https://vercel.com) → "Add New Project" → importe le dépôt
3. Dans les paramètres du projet Vercel, ajoute les mêmes variables que
   `.env.local` (Settings → Environment Variables)
4. Deploy. Tu obtiens une URL du type `glorifin.vercel.app`

## 5. Nom de domaine

Une fois déployé sur Vercel : Settings → Domains → ajoute `glorifin.fr` (ou
autre), achetée chez un registrar (OVH, Gandi...), et suis les instructions
DNS affichées par Vercel.

## Prochaines étapes vers un vrai produit

- Remplacer `scoreApplication()` par une vraie analyse de solvabilité
- Ajouter la vérification d'identité (KYC) — ex. prestataires comme Onfido, Sumsub
- Connexion à un bureau de crédit réel (nécessite les autorisations réglementaires)
- Emails transactionnels (confirmation de dossier, changement de statut) — ex. Resend, Postmark
- Mentions légales réelles, politique de confidentialité, CGU
- Démarche d'agrément ACPR ou partenariat avec un établissement déjà agréé

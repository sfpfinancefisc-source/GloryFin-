'use client';

import { useState } from 'react';
import { computeMonthly, fmtEUR } from '@/lib/scoring';

export default function LoanSimulator() {
  const [amount, setAmount] = useState(15000);
  const [months, setMonths] = useState(48);
  const monthly = computeMonthly(amount, months);

  return (
    <div className="sim-card">
      <div className="sim-card-head">
        <h3>Simulateur de crédit</h3>
        <div className="live"><span className="live-dot" />TAUX EN DIRECT</div>
      </div>

      <div className="sim-row">
        <div className="sim-row-head">
          <label>Montant emprunté</label>
          <span className="sim-value">{fmtEUR(amount)}</span>
        </div>
        <input type="range" min="1000" max="50000" step="500" value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
      </div>

      <div className="sim-row">
        <div className="sim-row-head">
          <label>Durée</label>
          <span className="sim-value">{months} mois</span>
        </div>
        <input type="range" min="6" max="84" step="6" value={months} onChange={(e) => setMonths(Number(e.target.value))} />
      </div>

      <div className="sim-result">
        <div>
          <div className="sim-result-label">MENSUALITÉ EST.</div>
          <div className="sim-result-amount">{fmtEUR(monthly)}</div>
        </div>
        <a href="/login" className="btn btn-primary">Démarrer</a>
      </div>

      <p className="sim-fine">
        Simulation indicative — TAEG fixe 4,9%. Sous réserve d'étude et d'acceptation du dossier.
        Un crédit vous engage et doit être remboursé.
      </p>
    </div>
  );
}

import './globals.css';

export const metadata = {
  title: 'GloryFin — Crédit aux particuliers',
  description: 'Simulation et demande de prêt en ligne.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}

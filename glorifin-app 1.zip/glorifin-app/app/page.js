import LoanSimulator from '@/app/components/LoanSimulator';

export default function LandingPage() {
  return (
    <div>
      <div className="ticker">
        <div className="ticker-track">
          <span>PRÊT PERSONNEL <b className="up">4,90%</b> TAEG fixe</span>
          <span>PRÊT AUTO <b className="up">3,90%</b> TAEG fixe</span>
          <span>DÉLAI DE RÉPONSE <b className="up">24H</b></span>
          <span>ÉTABLISSEMENT AGRÉÉ ACPR</span>
          <span>PRÊT PERSONNEL <b className="up">4,90%</b> TAEG fixe</span>
          <span>PRÊT AUTO <b className="up">3,90%</b> TAEG fixe</span>
          <span>DÉLAI DE RÉPONSE <b className="up">24H</b></span>
          <span>ÉTABLISSEMENT AGRÉÉ ACPR</span>
        </div>
      </div>

      <div className="nav">
        <a href="/" className="logo"><span className="logo-mark" /> GloryFin</a>
        <div style={{ display: 'flex', gap: 10 }}>
          <a href="/login" className="btn btn-ghost">Se connecter</a>
          <a href="/login" className="btn btn-primary">Simuler mon prêt</a>
        </div>
      </div>

      <section className="hero">
        <div className="wrap-wide hero-grid">
          <div>
            <div className="eyebrow">CRÉDIT À LA CONSOMMATION — RÉGLEMENTÉ ACPR</div>
            <h1 className="hero-h1">L'infrastructure de crédit pensée pour les particuliers.</h1>
            <p className="lead">
              Scoring instantané, taux fixe communiqué avant toute demande, décision sous 24h.
              Une mécanique de crédit transparente, du premier clic au virement.
            </p>
            <div className="hero-cta">
              <a href="#produits" className="btn btn-primary">Découvrir nos prêts</a>
              <a href="#securite" className="btn btn-ghost">Voir notre conformité</a>
            </div>
            <div className="badges">
              <div className="badge-outline"><span className="dot" />Agrément ACPR n°17439</div>
              <div className="badge-outline"><span className="dot" />Chiffrement AES-256</div>
              <div className="badge-outline"><span className="dot" />Conforme RGPD</div>
            </div>
          </div>

          <LoanSimulator />
        </div>
      </section>

      <div className="stats-band">
        <div className="wrap-wide stats-grid">
          <div className="stat"><div className="stat-num">4,9%</div><div className="stat-label">TAEG fixe dès</div></div>
          <div className="stat"><div className="stat-num">24h</div><div className="stat-label">Délai de décision</div></div>
          <div className="stat"><div className="stat-num">40k+</div><div className="stat-label">Dossiers financés</div></div>
          <div className="stat"><div className="stat-num">98%</div><div className="stat-label">Décisions automatisées</div></div>
        </div>
      </div>

      <section>
        <div className="wrap-wide">
          <div className="section-head">
            <div className="eyebrow" style={{ color: 'var(--ink-soft)' }}>PROCESSUS</div>
            <h2>De la demande au virement, en trois étapes</h2>
            <p>Un parcours entièrement digital, avec un conseiller disponible à chaque étape si besoin.</p>
          </div>
          <div className="steps">
            <div className="step">
              <span className="step-num">01 / SIMULATION</span>
              <h3>Vous simulez votre prêt</h3>
              <p>Montant, durée, mensualité : tout est visible avant toute demande, sans impact sur votre dossier de crédit.</p>
            </div>
            <div className="step">
              <span className="step-num">02 / ANALYSE</span>
              <h3>Notre moteur de scoring analyse le dossier</h3>
              <p>Étude automatisée et contrôle humain, avec une réponse communiquée sous 24h ouvrées.</p>
            </div>
            <div className="step">
              <span className="step-num">03 / VIREMENT</span>
              <h3>Signature électronique et fonds versés</h3>
              <p>Contrat signé en ligne, virement sur votre compte sous 48h après acceptation définitive.</p>
            </div>
          </div>
        </div>
      </section>

      <section id="produits">
        <div className="wrap-wide">
          <div className="section-head">
            <div className="eyebrow" style={{ color: 'var(--ink-soft)' }}>CATALOGUE</div>
            <h2>Nos produits de crédit</h2>
            <p>Des taux fixes, communiqués avant toute demande de dossier.</p>
          </div>
          <div className="products">
            <div className="product-row">
              <div><h3>Prêt personnel</h3><p>Financement libre de 1 000 € à 50 000 €, sans justificatif d'usage.</p></div>
              <div className="product-rate"><div className="val">4,9%</div><div className="lbl">TAEG fixe dès</div></div>
            </div>
            <div className="product-row">
              <div><h3>Prêt auto</h3><p>Véhicule neuf ou d'occasion, achat chez un particulier ou un professionnel.</p></div>
              <div className="product-rate"><div className="val">3,9%</div><div className="lbl">TAEG fixe dès</div></div>
            </div>
            <div className="product-row">
              <div><h3>Prêt travaux</h3><p>Rénovation, extension ou aménagement intérieur.</p></div>
              <div className="product-rate"><div className="val">4,2%</div><div className="lbl">TAEG fixe dès</div></div>
            </div>
            <div className="product-row">
              <div><h3>Regroupement de crédits</h3><p>Consolidation de plusieurs crédits en une seule mensualité.</p></div>
              <div className="product-rate"><div className="val">Sur devis</div><div className="lbl">selon profil</div></div>
            </div>
          </div>
        </div>
      </section>

      <section id="securite">
        <div className="wrap-wide">
          <div className="security">
            <div className="eyebrow" style={{ color: '#3ED598' }}>CONFORMITÉ & SÉCURITÉ</div>
            <h2>Un établissement régulé, une infrastructure auditée</h2>
            <p>GloryFin opère sous agrément ACPR et applique les standards de sécurité de l'industrie bancaire à chaque étape du parcours.</p>
            <div className="security-grid">
              <div className="sec-item">
                <span className="k">AGRÉMENT</span>
                <h3>Établissement de crédit agréé ACPR</h3>
                <p>Contrôlé par l'Autorité de contrôle prudentiel et de résolution.</p>
              </div>
              <div className="sec-item">
                <span className="k">CHIFFREMENT</span>
                <h3>Données protégées de bout en bout</h3>
                <p>Chiffrement AES-256 et infrastructure hébergée en Europe.</p>
              </div>
              <div className="sec-item">
                <span className="k">CONFORMITÉ</span>
                <h3>RGPD et lutte anti-fraude</h3>
                <p>Vérification d'identité et scoring conformes aux exigences réglementaires.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section>
        <div className="wrap-wide">
          <div className="cta-band">
            <div>
              <h2>Prêt à financer votre projet ?</h2>
              <p>Simulation gratuite, sans engagement, sans impact sur votre dossier.</p>
            </div>
            <a href="/login" className="btn btn-primary cta-btn">Simuler mon prêt</a>
          </div>
        </div>
      </section>

      <footer>
        <div className="wrap-wide">
          <div className="foot-grid">
            <div className="logo"><span className="logo-mark" /> GloryFin</div>
            <div className="foot-links">
              <a href="#produits">Nos prêts</a>
              <a href="#securite">Sécurité</a>
              <a href="/login">Espace client</a>
            </div>
          </div>
          <div className="foot-bottom">
            GloryFin — Démo à but illustratif. Taux, agréments et chiffres affichés sont fictifs.
          </div>
        </div>
      </footer>
    </div>
  );
}

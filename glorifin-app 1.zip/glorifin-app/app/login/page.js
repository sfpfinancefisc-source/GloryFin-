'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function LandingPage() {
  const router = useRouter();
  const supabase = createClient();

  const [mode, setMode] = useState('login'); // login | signup
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      if (mode === 'signup') {
        const { error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { name } },
        });
        if (signUpError) throw signUpError;
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) throw signInError;
      }
      router.push('/dashboard');
      router.refresh();
    } catch (err) {
      setError(err.message || 'Une erreur est survenue.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="nav">
        <a href="/" className="logo"><span className="logo-mark" /> GloryFin</a>
      </div>
      <div className="wrap">
        <div className="mono" style={{ color: 'var(--indigo)', fontSize: '0.8rem', fontWeight: 600, marginBottom: 12 }}>
          ESPACE CLIENT
        </div>
        <h1 style={{ fontSize: '1.7rem', marginBottom: 8 }}>
          {mode === 'login' ? 'Connectez-vous' : 'Créez votre compte'}
        </h1>
        <p style={{ color: 'var(--ink-soft)', fontSize: '0.92rem', marginBottom: 24 }}>
          Simulez et suivez votre demande de prêt en quelques minutes.
        </p>

        {error && <div className="error-banner">{error}</div>}

        <form onSubmit={handleSubmit} className="card">
          {mode === 'signup' && (
            <div className="field">
              <label>Nom complet</label>
              <input value={name} onChange={(e) => setName(e.target.value)} required />
            </div>
          )}
          <div className="field">
            <label>Email</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="field">
            <label>Mot de passe</label>
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={6} required />
          </div>
          <button className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Chargement...' : mode === 'login' ? 'Se connecter' : "S'inscrire"}
          </button>
        </form>

        <p style={{ fontSize: '0.85rem', color: 'var(--ink-soft)', marginTop: 16, textAlign: 'center' }}>
          {mode === 'login' ? "Pas encore de compte ? " : 'Déjà un compte ? '}
          <a
            href="#"
            style={{ color: 'var(--indigo)', fontWeight: 600 }}
            onClick={(e) => { e.preventDefault(); setMode(mode === 'login' ? 'signup' : 'login'); setError(''); }}
          >
            {mode === 'login' ? "S'inscrire" : 'Se connecter'}
          </a>
        </p>
      </div>
    </div>
  );
}

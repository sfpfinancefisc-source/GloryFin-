'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';
import { computeMonthly, scoreApplication, fmtEUR } from '@/lib/scoring';

export default function ApplyPage() {
  const router = useRouter();
  const supabase = createClient();

  const [amount, setAmount] = useState(15000);
  const [months, setMonths] = useState(48);
  const [income, setIncome] = useState(2200);
  const [purpose, setPurpose] = useState('Projet personnel');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const monthly = computeMonthly(amount, months);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) { router.push('/'); return; }

      const { status, note } = scoreApplication(amount, months, income);

      const { error: insertError } = await supabase.from('loan_applications').insert({
        user_id: user.id,
        amount,
        months,
        monthly,
        income,
        purpose,
        status,
        score_note: note,
      });
      if (insertError) throw insertError;

      router.push('/dashboard');
      router.refresh();
    } catch (err) {
      setError(err.message || "La demande n'a pas pu être envoyée.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div className="nav">
        <div className="logo"><span className="logo-mark" /> GloryFin</div>
      </div>
      <div className="wrap">
        <a href="/dashboard" className="btn btn-ghost" style={{ fontSize: '0.8rem', padding: '7px 12px', marginBottom: 16, display: 'inline-block' }}>
          ← Retour
        </a>
        <h2 style={{ fontSize: '1.5rem', marginBottom: 20 }}>Nouvelle demande de prêt</h2>

        {error && <div className="error-banner">{error}</div>}

        <form onSubmit={handleSubmit} className="card">
          <div className="field">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <label style={{ margin: 0 }}>Montant</label>
              <span className="mono" style={{ fontWeight: 600 }}>{fmtEUR(amount)}</span>
            </div>
            <input type="range" min="1000" max="50000" step="500" value={amount} onChange={(e) => setAmount(Number(e.target.value))} />
          </div>

          <div className="field">
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
              <label style={{ margin: 0 }}>Durée</label>
              <span className="mono" style={{ fontWeight: 600 }}>{months} mois</span>
            </div>
            <input type="range" min="6" max="84" step="6" value={months} onChange={(e) => setMonths(Number(e.target.value))} />
          </div>

          <div className="field">
            <label>Revenu mensuel net</label>
            <input type="number" min="0" value={income} onChange={(e) => setIncome(Number(e.target.value))} required />
          </div>

          <div className="field">
            <label>Objet du prêt</label>
            <select value={purpose} onChange={(e) => setPurpose(e.target.value)}>
              <option>Projet personnel</option>
              <option>Véhicule</option>
              <option>Travaux</option>
              <option>Regroupement de crédits</option>
            </select>
          </div>

          <div className="mensualite-box">
            <span className="lbl">MENSUALITÉ EST.</span>
            <span className="val">{fmtEUR(monthly)}</span>
          </div>

          <button className="btn btn-primary" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Envoi...' : 'Envoyer ma demande'}
          </button>
        </form>
      </div>
    </div>
  );
}

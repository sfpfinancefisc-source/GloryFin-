'use client';

import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';
import { fmtEUR } from '@/lib/scoring';

const STATUS_LABEL = { pending: 'En cours d\u2019examen', approved: 'Approuvé', rejected: 'Refusé' };
const STATUS_CLASS = { pending: 'badge-pending', approved: 'badge-approved', rejected: 'badge-rejected' };

export default function AdminList({ initialApplications }) {
  const supabase = createClient();
  const [applications, setApplications] = useState(initialApplications);
  const [error, setError] = useState('');

  async function updateStatus(id, status) {
    setError('');
    const { error: updateError } = await supabase
      .from('loan_applications')
      .update({ status })
      .eq('id', id);

    if (updateError) {
      setError("Impossible de mettre à jour ce dossier.");
      return;
    }
    setApplications((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));
  }

  if (applications.length === 0) {
    return <div className="card" style={{ textAlign: 'center', color: 'var(--ink-soft)' }}>Aucun dossier pour le moment.</div>;
  }

  return (
    <div>
      {error && <div className="error-banner">{error}</div>}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {applications.map((app) => (
          <div key={app.id} className="card">
            <div style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: 10, marginBottom: 10 }}>
              <div>
                <div style={{ fontWeight: 600 }}>{app.profiles?.name}</div>
                <div style={{ fontSize: '0.8rem', color: 'var(--ink-soft)' }}>{app.profiles?.email}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="mono" style={{ fontWeight: 600, color: 'var(--indigo)' }}>{fmtEUR(app.amount)}</div>
                <div style={{ fontSize: '0.78rem', color: 'var(--ink-soft)' }}>{app.months} mois · {fmtEUR(app.monthly)}/mois</div>
              </div>
            </div>
            <div style={{ fontSize: '0.82rem', color: 'var(--ink-soft)', marginBottom: 10 }}>
              {app.purpose} — Revenu déclaré {fmtEUR(app.income)}/mois
            </div>
            {app.score_note && (
              <div style={{ fontSize: '0.78rem', color: 'var(--ink-soft)', marginBottom: 12, fontStyle: 'italic' }}>
                {app.score_note}
              </div>
            )}
            <div style={{ display: 'flex', gap: 8, alignItems: 'center', flexWrap: 'wrap' }}>
              <span className={`badge ${STATUS_CLASS[app.status]}`}>{STATUS_LABEL[app.status]}</span>
              <select
                value={app.status}
                onChange={(e) => updateStatus(app.id, e.target.value)}
                style={{ padding: '7px 10px', fontSize: '0.8rem', borderRadius: 8, border: '1px solid var(--line)' }}
              >
                <option value="pending">En cours d'examen</option>
                <option value="approved">Approuver</option>
                <option value="rejected">Refuser</option>
              </select>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

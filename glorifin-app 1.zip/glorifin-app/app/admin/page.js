import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { fmtEUR } from '@/lib/scoring';
import AdminList from './AdminList';

export default async function AdminPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/');

  const { data: profile } = await supabase
    .from('profiles')
    .select('role')
    .eq('id', user.id)
    .single();

  if (profile?.role !== 'admin') redirect('/dashboard');

  const { data: applications } = await supabase
    .from('loan_applications')
    .select('*, profiles(name, email)')
    .order('created_at', { ascending: false });

  return (
    <div>
      <div className="nav">
        <div className="logo"><span className="logo-mark" /> GloryFin — Interne</div>
        <a href="/dashboard" className="btn btn-ghost">Retour espace client</a>
      </div>
      <div className="wrap-wide">
        <h2 style={{ fontSize: '1.4rem', marginBottom: 20 }}>Dossiers ({applications?.length || 0})</h2>
        <AdminList initialApplications={applications || []} />
      </div>
    </div>
  );
}

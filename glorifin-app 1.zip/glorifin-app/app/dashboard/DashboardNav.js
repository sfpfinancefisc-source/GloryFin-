'use client';

import { useRouter } from 'next/navigation';
import { createClient } from '@/lib/supabase/client';

export default function DashboardNav({ isAdmin }) {
  const router = useRouter();
  const supabase = createClient();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push('/');
    router.refresh();
  }

  return (
    <div className="nav">
      <div className="logo"><span className="logo-mark" /> GloryFin</div>
      <div style={{ display: 'flex', gap: 10 }}>
        {isAdmin && <a href="/admin" className="btn btn-ghost" style={{ fontSize: '0.8rem', padding: '8px 14px' }}>Espace interne</a>}
        <button className="btn btn-ghost" onClick={handleLogout}>Déconnexion</button>
      </div>
    </div>
  );
}

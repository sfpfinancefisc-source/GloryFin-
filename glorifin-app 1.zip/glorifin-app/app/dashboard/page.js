import { redirect } from 'next/navigation';
import { createClient } from '@/lib/supabase/server';
import { fmtEUR } from '@/lib/scoring';
import DashboardNav from './DashboardNav';

const STATUS_LABEL = { pending: 'En cours d\u2019examen', approved: 'Approuvé', rejected: 'Refusé' };
const STATUS_CLASS = { pending: 'badge-pending', approved: 'badge-approved', rejected: 'badge-rejected' };

export default async function DashboardPage() {
  const supabase = createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect('/');

  const { data: profile } = await supabase
    .from('profiles')
    .select('name, role')
    .eq('id', user.id)
    .single();

  const { data: applications } = await supabase
    .from('loan_applications')
    .select('*')
    .eq('user_id', user.id)
    .order('created_at', { ascending: false });

  return (
    <div>
      <DashboardNav name={profile?.name} isAdmin={profile?.role === 'admin'} />
      <div className="wrap-wide">
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, flexWrap: 'wrap', gap: 12 }}>
          <div>
            <h2 style={{ fontSize: '1.4rem' }}>Bonjour {profile?.name?.split(' ')[0] || ''}</h2>
            <p style={{ color: 'var(--ink-soft)', fontSize: '0.85rem' }}>{user.email}</p>
          </div>
          <a href="/apply" className="btn btn-primary">+ Nouvelle demande</a>
        </div>

        {(!applications || applications.length === 0) && (
          <div className="card" style={{ textAlign: 'center' }}>
            <p style={{ color: 'var(--ink-soft)', marginBottom: 14 }}>Aucune demande pour le moment.</p>
            <a href="/apply" className="btn btn-primary">Faire une simulation</a>
          </div>
        )}

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {applications?.map((app) => (
            <div key={app.id} className="card">
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 10 }}>
                <div className="mono" style={{ fontWeight: 600, fontSize: '1.1rem', color: 'var(--indigo)' }}>
                  {fmtEUR(app.amount)}
                </div>
                <span className={`badge ${STATUS_CLASS[app.status]}`}>{STATUS_LABEL[app.status]}</span>
              </div>
              <div style={{ fontSize: '0.85rem', color: 'var(--ink-soft)' }}>
                {app.purpose} · {app.months} mois · {fmtEUR(app.monthly)}/mois
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

-- ==========================================================
-- GloryFin — schéma de base de données
-- À exécuter dans Supabase: SQL Editor > New query > Run
-- ==========================================================

-- Profils utilisateurs (étend auth.users avec nom + rôle)
create table if not exists public.profiles (
  id uuid references auth.users on delete cascade primary key,
  email text not null,
  name text not null,
  role text not null default 'client' check (role in ('client', 'admin')),
  created_at timestamptz default now()
);

alter table public.profiles enable row level security;

create policy "Un utilisateur voit son propre profil"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Un admin voit tous les profils"
  on public.profiles for select
  using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

create policy "Un utilisateur met à jour son propre profil"
  on public.profiles for update
  using (auth.uid() = id);

-- Création automatique du profil à l'inscription
create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'name', new.email));
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Demandes de prêt
create table if not exists public.loan_applications (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references auth.users on delete cascade not null,
  amount numeric not null check (amount > 0),
  months integer not null check (months > 0),
  monthly numeric not null,
  income numeric not null,
  purpose text not null,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  score_note text,
  created_at timestamptz default now()
);

alter table public.loan_applications enable row level security;

create policy "Un client voit ses propres dossiers"
  on public.loan_applications for select
  using (auth.uid() = user_id);

create policy "Un client crée ses propres dossiers"
  on public.loan_applications for insert
  with check (auth.uid() = user_id);

create policy "Un admin voit tous les dossiers"
  on public.loan_applications for select
  using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

create policy "Un admin met à jour tous les dossiers"
  on public.loan_applications for update
  using (
    exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin')
  );

-- Pour transformer un compte en admin après inscription, exécute :
-- update public.profiles set role = 'admin' where email = 'toi@glorifin.fr';

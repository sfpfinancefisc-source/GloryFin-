import './globals.css';

export const metadata = {
  title: 'GloryFin — Solutions de financement',
  description: 'Simulation indicative et suivi de demande de financement en ligne.',
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body>{children}</body>
    </html>
  );
}

import LoanSimulator from '@/app/components/LoanSimulator';

const solutions = [
  {
    icon: '01',
    title: 'Prêt personnel',
    text: 'Un financement souple pour vos projets personnels, avec une simulation claire avant toute demande.',
  },
  {
    icon: '02',
    title: 'Financement auto',
    text: 'Préparez votre projet automobile et estimez votre mensualité directement en ligne.',
  },
  {
    icon: '03',
    title: 'Financement travaux',
    text: 'Planifiez vos travaux et adaptez le montant et la durée à votre budget.',
  },
];

const steps = [
  ['01', 'Simulez', 'Choisissez un montant et une durée pour obtenir une estimation indicative.'],
  ['02', 'Déposez votre demande', 'Renseignez les informations nécessaires à l’étude de votre projet.'],
  ['03', 'Suivez votre dossier', 'Retrouvez l’état de votre demande depuis votre espace personnel.'],
];

export default function LandingPage() {
  return (
    <div className="site-shell">
      <div className="announcement">
        <div className="wrap-wide announcement-inner">
          <span className="announcement-dot" />
          <span>Simulation en ligne · réponse selon étude du dossier</span>
          <span className="announcement-note">TAEG et conditions selon profil</span>
        </div>
      </div>

      <header className="site-nav">
        <div className="wrap-wide nav-inner">
          <a href="/" className="brand" aria-label="GloryFin accueil">
            <span className="brand-mark"><span /></span>
            <span>Glory<span>Fin</span></span>
          </a>

          <nav className="desktop-nav" aria-label="Navigation principale">
            <a href="#solutions">Solutions</a>
            <a href="#fonctionnement">Comment ça marche</a>
            <a href="#securite">Sécurité</a>
          </nav>

          <div className="nav-actions">
            <a href="/login" className="btn btn-light">Se connecter</a>
            <a href="#simulateur" className="btn btn-primary">Simuler</a>
          </div>
        </div>
      </header>

      <main>
        <section className="hero-modern">
          <div className="hero-glow hero-glow-one" />
          <div className="hero-glow hero-glow-two" />
          <div className="wrap-wide hero-modern-grid">
            <div className="hero-copy">
              <div className="eyebrow"><span /> FINANCEMENT DIGITAL</div>
              <h1>Votre projet.<br /><em>Votre financement.</em></h1>
              <p className="hero-lead">
                Une expérience simple pour simuler votre financement, déposer une demande
                et suivre votre dossier en ligne.
              </p>

              <div className="hero-actions">
                <a href="#simulateur" className="btn btn-primary btn-large">
                  Faire une simulation <span>↗</span>
                </a>
                <a href="#fonctionnement" className="text-link">Découvrir le parcours <span>→</span></a>
              </div>

              <div className="hero-trust">
                <div><strong>01</strong><span>Simulation<br />indicative</span></div>
                <div><strong>02</strong><span>Demande<br />en ligne</span></div>
                <div><strong>03</strong><span>Suivi depuis<br />votre espace</span></div>
              </div>
            </div>

            <div id="simulateur" className="hero-simulator">
              <div className="simulator-label"><span className="live-dot" /> SIMULATEUR</div>
              <LoanSimulator />
            </div>
          </div>
        </section>

        <section id="solutions" className="section-modern">
          <div className="wrap-wide">
            <div className="section-intro">
              <div>
                <div className="eyebrow"><span /> NOS SOLUTIONS</div>
                <h2>Un parcours pensé autour de votre projet.</h2>
              </div>
              <p>Des outils simples pour comprendre votre financement avant de déposer une demande.</p>
            </div>

            <div className="solution-grid">
              {solutions.map((item) => (
                <article className="solution-card" key={item.icon}>
                  <div className="solution-number">{item.icon}</div>
                  <div className="solution-icon">↗</div>
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                  <a href="#simulateur">Simuler <span>→</span></a>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section id="fonctionnement" className="section-modern process-section">
          <div className="wrap-wide">
            <div className="section-intro compact">
              <div>
                <div className="eyebrow"><span /> COMMENT ÇA MARCHE</div>
                <h2>Simple du premier clic au suivi.</h2>
              </div>
            </div>

            <div className="process-grid">
              {steps.map(([number, title, text]) => (
                <div className="process-card" key={number}>
                  <span className="process-number">{number}</span>
                  <div className="process-line" />
                  <h3>{title}</h3>
                  <p>{text}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="securite" className="security-modern">
          <div className="wrap-wide">
            <div className="security-panel">
              <div className="security-copy">
                <div className="eyebrow eyebrow-green"><span /> SÉCURITÉ & TRANSPARENCE</div>
                <h2>Des informations claires, sans promesse trompeuse.</h2>
                <p>
                  Les simulations sont indicatives. Toute demande est soumise à une étude
                  et à l’acceptation des conditions applicables.
                </p>
                <a href="/login" className="btn btn-white">Accéder à mon espace <span>→</span></a>
              </div>

              <div className="security-points">
                <div><span>✓</span><div><strong>Données protégées</strong><small>Connexion sécurisée et bonnes pratiques de protection des données.</small></div></div>
                <div><span>✓</span><div><strong>Conditions affichées</strong><small>Les informations essentielles sont présentées avant toute démarche.</small></div></div>
                <div><span>✓</span><div><strong>Suivi du dossier</strong><small>Retrouvez vos demandes et leur statut depuis votre espace personnel.</small></div></div>
              </div>
            </div>
          </div>
        </section>

        <section className="final-cta">
          <div className="wrap-wide">
            <div className="cta-modern">
              <div>
                <div className="eyebrow eyebrow-light"><span /> COMMENCEZ EN QUELQUES CLICS</div>
                <h2>Calculez votre mensualité.</h2>
                <p>Une première estimation, sans engagement.</p>
              </div>
              <a href="#simulateur" className="btn btn-white btn-large">Lancer le simulateur <span>↗</span></a>
            </div>
          </div>
        </section>
      </main>

      <footer className="footer-modern">
        <div className="wrap-wide">
          <div className="footer-top">
            <a href="/" className="brand brand-footer">
              <span className="brand-mark"><span /></span>
              <span>Glory<span>Fin</span></span>
            </a>
            <div className="footer-links">
              <a href="#solutions">Solutions</a>
              <a href="#fonctionnement">Fonctionnement</a>
              <a href="#securite">Sécurité</a>
              <a href="/login">Espace client</a>
            </div>
          </div>
          <div className="footer-bottom">
            <span>© GloryFin — Démonstration illustrative.</span>
            <span>Les taux, conditions et informations réglementaires doivent être vérifiés avant toute utilisation publique.</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
